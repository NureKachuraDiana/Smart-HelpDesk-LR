﻿---
name: tracker-slice
description: Use when implementing or testing one bounded Smart HelpDesk API slice from the approved Lab 1 specification, such as issue creation, issue updates, status transitions, comments, or filtering.
---

# Smart HelpDesk — tracker-slice

## Purpose

Implement one small, clearly defined part of the Smart HelpDesk REST API without changing the approved Lab 1 contract.

## Required context

Before making changes, read:

- `docs/traceability.csv`
- `.agents/skills/tracker-slice/references/slices.md`
- The relevant Lab 1 API requirements and contract supplied by the project owner.

If the original Lab 1 requirements or API contract are unavailable, report this limitation. Do not invent requirements.

## Procedure

1. Identify the requested slice (A, B, C, or D).
2. Check its scope and acceptance criteria.
3. Provide a short implementation plan.
4. Change only files needed for that slice and its tests.
5. Keep the existing API contract unchanged.
6. Use parameterized SQL queries and preserve database records.
7. Add or update tests for normal cases and relevant errors.
8. Inspect the diff for unrelated changes, destructive operations, external network access, and changes outside the project.
9. Run relevant tests and Ruff checks.
10. Report changed files, test results, and remaining limitations.

## Restrictions

- Do not implement functionality outside the approved Lab 1 scope.
- Do not implement FR-08 AI recommendations in Lab 2.
- Do not add authentication, a frontend, cloud services, Docker, file uploads, or notifications.
- Do not change dependencies or API contracts without explicit approval.
- Do not delete or reset existing issue records.
- Do not weaken or remove tests to make them pass.
- Do not expose SQL errors, tracebacks, or local file paths in API responses.
- Do not make unrelated refactoring.
- Do not run destructive commands.
- Make no more than two focused correction attempts after the first test run.
- The user decides whether proposed changes are accepted.
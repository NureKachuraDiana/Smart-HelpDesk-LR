﻿# Smart HelpDesk implementation slices

This file defines the allowed implementation boundaries for the tracker-slice Skill.

## Slice A — Issue creation and reading

Scope:
- POST /issues
- GET /issues
- GET /issues/{id}

Acceptance checks:
- A valid issue can be created.
- The server generates the ID and creation timestamp.
- New issues receive the specified default status and priority.
- Issues can be listed and retrieved by ID.
- Unknown fields and invalid values are rejected.
- A missing issue returns 404.

## Slice B — Issue updates and status

Scope:
- PATCH /issues/{id}
- PATCH /issues/{id}/status

Acceptance checks:
- Only permitted issue fields can be updated.
- An empty update is rejected.
- Invalid updates do not partially modify the record.
- Status transitions follow the Lab 1 transition matrix.
- Closed issues cannot be edited or reopened.
- A missing issue returns 404.
- An invalid status transition returns 409.

## Slice C — Comments

Scope:
- POST /issues/{id}/comments
- GET /issues/{id}/comments

Acceptance checks:
- A comment is linked to an existing issue.
- The author must be one of the seeded users.
- Comment text is validated according to the Lab 1 contract.
- Comments are returned in a stable order.
- A missing issue returns 404.

## Slice D — Filtering

Scope:
- GET /issues?status=...
- GET /issues?priority=...
- Combined status and priority filters.

Acceptance checks:
- Status filtering works.
- Priority filtering works.
- Combined filters use AND logic.
- No matches return an empty list with HTTP 200.
- Results use the ordering specified in Lab 1.

## General boundaries

- Do not add routes that are not in the approved Lab 1 contract.
- Do not implement FR-08 AI recommendations in Lab 2.
- Preserve SQLite data between application restarts.
- Keep tests isolated from the real application database.
- Use only synthetic test data.
